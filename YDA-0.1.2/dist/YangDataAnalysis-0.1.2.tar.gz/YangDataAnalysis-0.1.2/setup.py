import setuptools
setuptools.setup(
    name="YangDataAnalysis",
    version="0.1.2",
    author="River_HE1000_0001_1000",
    author_email="2004818cngz@gmail.com",
    description="",
    long_description="Nil",
    long_description_content_type="text",
    url="https://github.com/RiverHYH/",
    packages=setuptools.find_packages(),
    classifiers=["Programming Language :: Python :: 3",
                 "License :: OSI Approved :: MIT License",
                 "Operating System :: OS Independent",
                 ],   
)