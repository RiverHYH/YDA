def MinMaxNormaliser(Array):#Normalise the numeric values into floats using Min_Max method
    Normalised_Array=[]
    Min=min(Array)
    Max=max(Array)
    for i in Array:
        Normalised_Value=(i-Min)/(Max-Min)
        Normalised_Array.append(Normalised_Value)
    return Normalised_Array