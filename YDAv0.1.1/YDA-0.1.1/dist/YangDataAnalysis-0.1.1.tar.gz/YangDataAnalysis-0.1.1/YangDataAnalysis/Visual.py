def GetCorrHeat(df):

    try:
        sns.set_context({'figure.figsize':[20, 20]}) #Set Fig Size
    except:
        raise("Dependencies Unsatisfied.You can use 'SetEnv()'to set up the dependencies")
    
   
    Corr=df.corr(numeric_only=True)
    #Create a triangle masks to cover dublicated coeficients
    mask = np.zeros_like(Corr)
    mask[np.triu_indices_from(mask)] = True
    with sns.axes_style("white"):
         #Generate Heatmap ranged[1:-1] and centred 0
        sns.heatmap(Corr,cmap="RdBu_r",annot=True,linewidths=1,fmt=".1g",center=0,vmax=1,vmin=-1,mask=mask)